const mongoose = require('mongoose');

const EeeSchema = new mongoose.Schema({
    projectId: {
        type: String,
        required: [true, 'projectId is mandatory']
    },
    ProjectName: {
        type: String,
        required: [true, 'ProjectName is mandatory']
    },
    dept: {
        type: String,
        required: [true, 'dept is mandatory']
    },
    categories: {
        type: String,
        required: [true, 'categories is mandatory']
    },
    subcategories: {
        type: String,
        required: [true, 'subcategories is mandatory']
    }
    ,
    createdAt: {
        type: Date,
        default: Date.now
    }
});
const eee = mongoose.model('Eee', EeeSchema);


module.exports = eee