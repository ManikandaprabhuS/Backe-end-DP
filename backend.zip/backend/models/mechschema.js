const mongoose = require('mongoose');

const MechSchema = new mongoose.Schema({
    projectId: {
        type: String,
        required: [true, 'projectId is mandatory']
    },
    ProjectName: {
        type: String,
        required: [true, 'ProjectName is mandatory']
    },
    dept: {
        type: String,
        required: [true, 'dept is mandatory']
    },
    categories: {
        type: String,
        required: [true, 'categories is mandatory']
    },
    subcategories: {
        type: String,
        required: [true, 'subcategories is mandatory']
    }
        // count: {
        //     type: Number,
        //     default: 1
        // },
        // does:{
        //     type: Boolean
        // }}],
        ,
    // viewCount: {
    //     type: Number,
    //     default: 1
    // },

    createdAt: {
        type: Date,
        default: Date.now
    }
});
const mech = mongoose.model('mechanical', MechSchema);


module.exports = mech