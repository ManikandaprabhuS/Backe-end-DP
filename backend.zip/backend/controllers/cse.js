const cse = require('../models/cseschema');
const asyncHandler = require('../middleware/async');

const getAllProjects = asyncHandler(async (req, res) => {
     res.status(200).json(res.advancedResults)
})



module.exports = { getAllProjects };