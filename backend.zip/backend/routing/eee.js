const express = require('express');
const router = express.Router();
var advancedFind = require('../middleware/advancedFind');
const eee =require('../models/eeeschema')
const { getAllProjects } = require('../controllers/eee');


router.get('/allprojects',advancedFind(eee),getAllProjects)

module.exports = router;