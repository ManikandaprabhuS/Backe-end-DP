const express = require('express');
const router = express.Router();
var advancedFind = require('../middleware/advancedFind');
const mech = require('../models/mechschema');
const { getAllProjects } = require('../controllers/mechanical');


router.get('/allprojects',advancedFind(mech),getAllProjects)

module.exports = router;