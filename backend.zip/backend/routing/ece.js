const express = require('express');
const router = express.Router();
var advancedFind = require('../middleware/advancedFind');
const ece =require('../models/eceschema')
const { getAllProjects } = require('../controllers/ece');


router.get('/allprojects',advancedFind(ece),getAllProjects)

module.exports = router;