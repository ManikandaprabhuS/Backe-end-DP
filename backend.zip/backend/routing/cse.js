const express = require('express');
const router = express.Router();
var advancedFind = require('../middleware/advancedFind');
const cse =require('../models/cseschema')
const { getAllProjects } = require('../controllers/cse');


router.get('/allprojects',advancedFind(cse),getAllProjects)

module.exports = router;