const express = require('express');
const router = express.Router();
var advancedFind = require('../middleware/advancedFind');
const civil =require('../models/civilschema')
const { getAllProjects } = require('../controllers/civil');


router.get('/allprojects',advancedFind(civil),getAllProjects)

module.exports = router;