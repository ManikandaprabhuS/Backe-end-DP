const express = require('express');
var cors = require('cors');
const app = express();

const databaseConnection = require('./db');
const errorHandler = require('./middleware/errorHandler');
const mechanicalRoute = require('./routing/mechanical')
const civilRoute =require('./routing/civil')
const cseRoute =require('./routing/cse')
const eceRoute =require('./routing/ece')
const eeeRoute= require('./routing/eee')
require('dotenv').config()
app.use(express.json());
app.use(express.urlencoded());
app.use(cors());

databaseConnection();

app.use('/api/v1/mechanical',mechanicalRoute)
app.use('/api/v1/civil',civilRoute)
app.use('/api/v1/cse',cseRoute)
app.use('/api/v1/ece',eceRoute)
app.use('/api/v1/eee',eeeRoute)

app.use(errorHandler);

app.listen(process.env.PORT, () => { console.log("Server Running on 8080") })